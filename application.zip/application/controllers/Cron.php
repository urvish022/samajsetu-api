<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Cron extends MY_Controller 
{
    /**
     * This is default constructor of the class
     */
    public function __construct()
    {
      parent::__construct();
      $this->load->model('Sql_builder','sb');
    }
      
    public function slider_cron()
    {
      $rows = $this->sb->fetch_slider_data();
      $total = count($rows);
      $current_date = strtotime(date('Y-m-d'));
      if($total > 0)
      {
        for($i=0;$i<$total;$i++)
        {
          $expire_date = strtotime($rows[$i]['slider_enddate']);
          if($expire_date <= $current_date)
          {
              switch ($rows[$i]['slider_name']) {
                  case 'slider1':
                  $slider_photo = 'slider1.jpg';
                  break;

                  case 'slider2':
                  $slider_photo = 'slider2.jpg';
                  break;

                  case 'slider3':
                  $slider_photo = 'slider3.jpg';
                  break;

                  case 'slider4':
                  $slider_photo = 'slider4.jpg';
                  break;

                  case 'slider5':
                  $slider_photo = 'slider5.jpg';
                  break;
                
                default:
                  $slider_photo = 'slider1.jpg';
                  break;
              }

              $business_id = 0;
              $slider_id = $rows[$i]['slider_id'];
              $where = array('slider_id'=>$slider_id);
              $data = array('slider_photo'=>$slider_photo,'business_id'=>0);
              $this->sb->update('slider_setting',$data,$where);
          }
        }
        
      }    
    }

    public function business_cron()
    {
      
    }  
}
?>
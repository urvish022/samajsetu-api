<!-- BEGIN FOOTER -->
    <div class="page-footer">
        <div class="page-footer-inner"> <?=date('Y');?> &copy; 
            <a target="_blank" href="https://www.samajsetu.com/">Samaj Setu</a> &nbsp;|&nbsp; Powered By
            
            <a href="http://techwebsoft.com" target="_blank">Techwebsoft</a>
        </div>
        <div class="scroll-to-top">
            <i class="icon-arrow-up"></i>
        </div>
    </div>
<!-- END FOOTER -->